package com.polware.diceroller

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity
import java.util.*

class MainActivity : AppCompatActivity() {
    // Store dice images in array
    private var imagesArray = intArrayOf(
        R.drawable.dice_1,
        R.drawable.dice_2,
        R.drawable.dice_3,
        R.drawable.dice_4,
        R.drawable.dice_5,
        R.drawable.dice_6)
    lateinit var diceImage: ImageView
    lateinit var buttonRoll: Button
    // Thread sleep time
    private var delayTime = 15
    // Number roll animations
    private var rollAnimations = 30
    // Define a Random object
    private var random: Random = Random()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        diceImage = findViewById(R.id.imageViewDie)
        buttonRoll = findViewById(R.id.buttonRoll)
        buttonRoll.setOnClickListener {
            rollTheDice()
        }
    }

    private fun rollTheDice() {
        // Define a Runnable object
        val runnable = Runnable {
            for (i in 0 until rollAnimations) {
                // Generate random number between 1 and 6
                var diceNumber = random.nextInt(6)
                // Set the image from above random number
                diceImage.setImageResource(imagesArray[diceNumber])
                try {
                    Thread.sleep(delayTime.toLong())
                } catch (e: InterruptedException) {
                    e.printStackTrace()
                }
            }
        }
        // Define Thread object
        val thread = Thread(runnable)
        // Start the thread
        thread.start()
    }
}